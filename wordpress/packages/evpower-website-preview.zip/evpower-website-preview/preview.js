
(() => {
 const message='Design preview: requests are not sent. Call +251 911 049 916 or use WhatsApp to contact Evpower.';
 const toast=()=>{let el=document.querySelector('.evs-preview-toast');if(el)el.remove();
  el=document.createElement('div');el.className='evs-preview-toast';el.role='status';
  el.textContent=message;document.body.append(el);setTimeout(()=>el.remove(),6500);};
 document.querySelectorAll('form[data-preview-form]').forEach(form=>{
  const select=form.querySelector('select[name="service"]');
  const service=new URLSearchParams(location.search).get('service');
  if(select&&[...select.options].some(o=>o.value===service))select.value=service;
  form.addEventListener('submit',event=>{event.preventDefault();
   let note=form.querySelector('.evs-preview-feedback');
   if(!note){note=document.createElement('p');note.className='evs-preview-feedback';
    note.setAttribute('role','status');form.append(note);}note.textContent=message;toast();});
 });
 document.addEventListener('click',event=>{
  if(event.target.closest('[data-preview-only]')){event.preventDefault();toast();return;}
  const open=event.target.closest('.wp-block-navigation__responsive-container-open');
  const close=event.target.closest('.wp-block-navigation__responsive-container-close');
  if(open||close){event.preventDefault();const nav=(open||close).closest('nav');
   const panel=nav?.querySelector('.wp-block-navigation__responsive-container');
   if(panel){panel.classList.toggle('is-menu-open',!!open);panel.classList.toggle('has-modal-open',!!open);
    panel.setAttribute('aria-hidden',close?'true':'false');open?.setAttribute('aria-expanded','true');
    document.documentElement.classList.toggle('has-modal-open',!!open);
    (open?panel.querySelector('.wp-block-navigation__responsive-container-close'):nav.querySelector('.wp-block-navigation__responsive-container-open'))?.focus();}}
  const title=event.target.closest('.elementor-tab-title');
  if(title){event.preventDefault();const body=document.getElementById(title.getAttribute('aria-controls'))||title.nextElementSibling;
   const active=title.getAttribute('aria-expanded')==='true';title.setAttribute('aria-expanded',String(!active));
   title.classList.toggle('elementor-active',!active);if(body){body.hidden=active;body.style.display=active?'none':'block';body.classList.toggle('elementor-active',!active);}}
 });
 document.addEventListener('keydown',event=>{if(event.key==='Escape'){
  document.querySelectorAll('.wp-block-navigation__responsive-container.is-menu-open').forEach(panel=>{
   panel.classList.remove('is-menu-open','has-modal-open');panel.setAttribute('aria-hidden','true');
   panel.closest('nav')?.querySelector('.wp-block-navigation__responsive-container-open')?.focus();});
  document.documentElement.classList.remove('has-modal-open');}});
 document.querySelectorAll('.elementor-tab-title').forEach(title=>{
  title.setAttribute('tabindex','0');title.addEventListener('keydown',event=>{
   if(event.key==='Enter'||event.key===' '){event.preventDefault();title.click();}});
 });
 document.querySelectorAll('.elementor-tab-content').forEach(panel=>{
  const title=document.querySelector('[aria-controls="'+panel.id+'"]');
  const active=title?.getAttribute('aria-expanded')==='true';panel.hidden=!active;panel.style.display=active?'block':'none';
 });
})();
